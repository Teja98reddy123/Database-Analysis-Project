create database library;
use library;


create table tbl_publisher(
pb_name varchar(255) primary key,
pb_address varchar(255),
pb_phn varchar(255));
select * from tbl_publisher;

create table tbl_book(
bk_id int primary key auto_increment,
bk_title varchar(100),
bk_publishername varchar(255),
foreign key (bk_publishername) references tbl_publisher(pb_name)
ON UPDATE CASCADE
ON DELETE CASCADE );

select * from tbl_book;

create table tbl_book_authors(
bk_authors_authorid int primary key auto_increment,
bk_authors_bookid int,
bk_authors_authorname varchar(255),
foreign key (bk_authors_bookid) references tbl_book(bk_id)
ON UPDATE CASCADE
ON DELETE CASCADE );
select * from tbl_book_authors;

create table library_branch(
l_branchid int primary key auto_increment,
l_bname varchar(255),
l_baddress varchar(255));

 select * from library_branch;
 
 create table tbl_book_copies(
  bk_copyid int primary key auto_increment,
  bk_copy_bookid int,
  bk_copy_branchid int,
  bk_ncopies int,
 foreign key (bk_copy_bookid) references  tbl_book(bk_id)
 ON UPDATE CASCADE ON DELETE CASCADE,
 foreign key (bk_copy_branchid) references library_branch(l_branchid)
 ON UPDATE CASCADE ON DELETE CASCADE);
 
 select * from tbl_book_copies;
 
create table tbl_borrower(
borrower_cardno int primary key auto_increment,
borrower_name varchar(255),
borrower_address varchar(255),
borrower_phn varchar(255));

select * from tbl_borrower;

create table tbl_book_loans(
bk_loansid int primary key auto_increment,
bk_loans_bookid int,
bk_loans_branchid int,
bk_loan_cardno int,
bk_loans_dateout date,
bk_loans_duedate date,
 foreign key (bk_loans_bookid) references  tbl_book(bk_id)
 ON UPDATE CASCADE ON DELETE CASCADE,
 foreign key (bk_loans_branchid) references library_branch( l_branchid)
 ON UPDATE CASCADE ON DELETE CASCADE,
 foreign key (bk_loan_cardno) references tbl_borrower(borrower_cardno)
 ON UPDATE CASCADE ON DELETE CASCADE);
 
 select * from tbl_book_loans;
 

 -- How many copies of the book titled "The Lost Tribe" are owned by the 
 -- library branch whose name is "Sharpstown"?
 
 select bk_title,l_bname,bk_ncopies from tbl_book as b
 join tbl_book_copies as c
 on b.bk_id = c.bk_copyid
 join library_branch as l
 on l.l_branchid = c.bk_copy_branchid
 where (bk_title ="The Lost Tribe" and l_bname ="Sharpstown");
 
 -- 2.How many copies of the book titled "The Lost Tribe" are owned by each library branch?
 
 select * from tbl_book, tbl_book_copies, library_branch;

select b.bk_title, lb.l_bname, bc.bk_ncopies as c
from tbl_book_copies as bc
join library_branch as lb on lb.l_branchid = bc.bk_copy_branchid
join tbl_book as b on b.bk_id = bc.bk_copy_bookid
where (b.bk_title = "The Lost Tribe")
order by c desc; 

-- 3. Retrieve the names of all borrowers who do not have any books checked out.

select * from tbl_borrower;
select borrower_cardno,borrower_name  from tbl_book_loans as l
right join tbl_borrower as b
on b.borrower_cardno = l.bk_loan_cardno
where l.bk_loan_cardno is null;

/* 4.For each book that is loaned out from the "Sharpstown" branch 
and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, 
and the borrower's address.  */

select bk.bk_title,b.borrower_name,b.borrower_address from tbl_book_loans as l
join tbl_book as bk on bk.bk_id = l.bk_loans_bookid
join library_branch as lb on lb.l_branchid = l.bk_loans_branchid
join tbl_borrower as b on b.borrower_cardno = l.bk_loan_cardno 
where lb.l_bname = "Sharpstown" and l.bk_loans_duedate = "2018-02-03"
order by bk.bk_title desc;


/* 5.For each library branch, retrieve the branch name and the total number 
of books loaned out from that branch.  */

select lb.l_bname,count(l.bk_loans_bookid) from library_branch as lb
join tbl_book_loans as l
on lb.l_branchid = l.bk_loans_branchid
group by lb.l_bname;

/* 6.Retrieve the names, addresses, and number of books checked out for 
all borrowers who have more than five books checked out.  */

select bk_loan_cardno,count(*) from  tbl_book_loans
group by bk_loan_cardno
having count(*)>5 ;
select borrower_name,borrower_address,borrower_phn from  tbl_borrower
where borrower_cardno in (select bk_loan_cardno  from  tbl_book_loans
group by bk_loan_cardno
having count(*)>5);

/* 7.For each book authored by "Stephen King", retrieve the title 
and the number of copies owned by the library branch whose name is "Central". */

select * from tbl_book_authors;
select * from library_branch;
select * from tbl_book_copies;
select bk_title,bk_ncopies from tbl_book as b
join tbl_book_copies as bc on bc.bk_copy_bookid = b.bk_id
join library_branch as l on l.l_branchid = bc.bk_copy_branchid
join tbl_book_authors as a on a.bk_authors_bookid = b.bk_id
where a.bk_authors_authorname ="Stephen King" and l.l_bname="central";

