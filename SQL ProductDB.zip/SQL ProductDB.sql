CREATE TABLE Products1(
ProductID int,
ProductName varchar(200),
Category varchar(150),
Price int,
StockQunatity varchar(250),
ManufactureDate date,
EXpiryDate date,
SupplierName varchar(350));
select * from Products1;
ALTER TABLE Products1 ADD Descrption varchar(380);
ALTER TABLE Products1 MODIFY EXpiryDate varchar(180);
ALTER TABLE Products1 Drop EXpiryDate;
select * from Products1;
ALTER TABLE Products1 modify ProductName varchar(360)unique;
select * from Products1;
ALTER TABLE Products1 DROP ProductName
DESC Products1;
ALTER TABLE Products1 RENAME column Price TO ProductPrice;