CREATE TABLE Patients (
    PatientID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50) ,
    DateOfBirth DATE ,
    Gender CHAR ,
    ContactNumber VARCHAR(15),
    Address varchar(200));
    select * from Patients;

create table Doctors (
DoctorID INT AUTO_INCREMENT PRIMARY KEY,
FirstName VARCHAR(60),
LastName VARCHAR(90) ,
Specialization VARCHAR(90),
ContactNumber INT,
EMail VARCHAR(100));
SELECT * FROM Doctors;

CREATE TABLE Appoinments (
AppoinmentID INT AUTO_INCREMENT PRIMARY KEY,
PatientID INT references Patients(PatientID),
DoctorID INT references Doctors(DoctorID),
AppoinmentDate Date, Diagnosis varchar(150));
ALTER TABLE Patients ADD Email varchar(150);
select *  from Patients;

ALTER TABLE Doctors MODIFY ContactNumber varchar(150);
ALTER TABLE Patients DROP column Address;
ALTER TABLE Doctors add constraint unique_email unique(EMail);
ALTER TABLE Doctors DROP constraint unique_email ;
ALTER TABLE Appoinments RENAME column Diagnosis to MedicalDiagnosis;

select * from Patients;
INSERT INTO Patients (FirstName, LastName, DateOfBirth, Gender, ContactNumber, Email)
VALUES
('Ram', 'Reddy', '1985-06-15', 'M', '555-1234', 'ramreddy@gmail.com'),
('Raja', 'Reddy', '2001-06-11', 'M', '6-34', 'rajareddy@gmail.com')

select * from Doctors;
INSERT INTO Doctors (FirstName, LastName, Specialization, ContactNumber)
VALUES
('Ram', 'Reddy', 'MBBS', '8978300732'),
('Raja', 'Reddy', 'Dentist','+9139329333')

select * from Appoinments;

INSERT INTO Appoinments (AppoinmentID, PatientID, DoctorID, AppoinmentDate,MedicaLDiagnosis)
VALUES
(7, 30, '80','2002-11-1','knee'),
(8,31,81,'2001-10-30','heart');
select * from Appoinments;

select * from Doctors;

UPDATE Doctors SET Specialization = 'Heart' WHERE DoctorID = 2;
select * from Patients;

Delete From Patients where PatientID=4;

select * from Patients,Doctors,Appoinments;




